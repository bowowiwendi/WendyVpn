from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import paramiko
import subprocess
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///ssh-panel.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True)
    password = db.Column(db.String(100))
    is_admin = db.Column(db.Boolean, default=False)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route('/')
@login_required
def dashboard():
    return render_template('dashboard.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        
        if user and check_password_hash(user.password, password):
            login_user(user)
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/manage-ssh')
@login_required
def manage_ssh():
    # Get list of SSH users
    users = []
    try:
        result = subprocess.run(['cat', '/etc/passwd'], capture_output=True, text=True)
        for line in result.stdout.split('\n'):
            if '/bin/bash' in line or '/bin/false' in line:
                parts = line.split(':')
                if len(parts) >= 7:
                    users.append({
                        'username': parts[0],
                        'uid': parts[2],
                        'home': parts[5],
                        'shell': parts[6]
                    })
    except Exception as e:
        flash(f'Error getting SSH users: {str(e)}')
    
    return render_template('manage_ssh.html', users=users)

@app.route('/add-user', methods=['POST'])
@login_required
def add_user():
    if not current_user.is_admin:
        flash('You do not have permission to perform this action')
        return redirect(url_for('manage_ssh'))
    
    username = request.form['username']
    password = request.form['password']
    
    try:
        # Create user
        subprocess.run(['useradd', '-m', '-s', '/bin/bash', username], check=True)
        # Set password
        subprocess.run(['chpasswd'], input=f'{username}:{password}', text=True, check=True)
        flash(f'User {username} created successfully')
    except subprocess.CalledProcessError as e:
        flash(f'Error creating user: {str(e)}')
    
    return redirect(url_for('manage_ssh'))

@app.route('/delete-user/<username>')
@login_required
def delete_user(username):
    if not current_user.is_admin:
        flash('You do not have permission to perform this action')
        return redirect(url_for('manage_ssh'))
    
    if username == 'root':
        flash('Cannot delete root user')
        return redirect(url_for('manage_ssh'))
    
    try:
        subprocess.run(['userdel', '-r', username], check=True)
        flash(f'User {username} deleted successfully')
    except subprocess.CalledProcessError as e:
        flash(f'Error deleting user: {str(e)}')
    
    return redirect(url_for('manage_ssh'))

@app.route('/change-password', methods=['POST'])
@login_required
def change_password():
    username = request.form['username']
    password = request.form['password']
    
    if not current_user.is_admin and current_user.username != username:
        flash('You do not have permission to perform this action')
        return redirect(url_for('manage_ssh'))
    
    try:
        subprocess.run(['chpasswd'], input=f'{username}:{password}', text=True, check=True)
        flash(f'Password for {username} changed successfully')
    except subprocess.CalledProcessError as e:
        flash(f'Error changing password: {str(e)}')
    
    return redirect(url_for('manage_ssh'))

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        # Create admin user if not exists
        admin = User.query.filter_by(username='admin').first()
        if not admin:
            admin = User(username='admin', password=generate_password_hash('admin'), is_admin=True)
            db.session.add(admin)
            db.session.commit()
    app.run(debug=True)