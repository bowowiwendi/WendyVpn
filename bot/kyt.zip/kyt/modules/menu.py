from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline("🔐 SSH OVPN","ssh")],
        [Button.inline("📡 VMess","vmess"),
         Button.inline("🔷 VLess","vless")],
        [Button.inline("🔰 Trojan","trojan"),
         Button.inline("🌑 Shadowsocks","shadowsocks")],
        [Button.inline("ℹ️ VPS Info","info"),
         Button.inline("⚙️ Setting","setting")],
        [Button.url("📞 Hubungi Admin", globals().get('ADMIN_CONTACT', 'https://t.me/WendiVpn'))]]
    sender = await event.get_sender()
    val = valid(str(sender.id))
    if val == "false":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except:
            await event.reply("Akses Ditolak")
    elif val == "true":
        sh = 'cat /etc/ssh/.ssh.db | grep "###" | wc -l'
        ssh = subprocess.check_output(sh, shell=True).decode("ascii")
        vm = 'cat /etc/xray/config.json | grep "###" | wc -l'
        vms = subprocess.check_output(vm, shell=True).decode("ascii")
        vl = 'cat /etc/vless/.vless.db | grep "###" | wc -l'
        vls = subprocess.check_output(vl, shell=True).decode("ascii")
        tr = 'cat /etc/trojan/.trojan.db | grep "###" | wc -l'
        trj = subprocess.check_output(tr, shell=True).decode("ascii")
        ss = 'cat /etc/shadowsocks/.shadowsocks.db | grep "###" | wc -l'
        ssk = subprocess.check_output(ss, shell=True).decode("ascii")
        user_id = sender.id
        username = sender.username
        sn = globals().get('STORE_NAME', '🏪 Store')
        msg = f"""
👤 **PANEL ADMIN**

Halo, **Admin**!
{sn}

🌐 **Host** : `{DOMAIN}`
📊 **SSH** : `{ssh.strip()}` akun | **VMess** : `{vms.strip()}` | **VLess** : `{vls.strip()}` | **Trojan** : `{trj.strip()}` | **SS** : `{ssk.strip()}`
🆔 **ID** : `{user_id}` | 👤 **@{username}`
"""
        try:
            await event.edit(msg,buttons=inline)
        except:
            await event.reply(msg,buttons=inline)


