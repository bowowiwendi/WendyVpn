from kyt import *
from datetime import datetime, timedelta

RECOVERY_PREFIXES = {
    'rercvm': ('###', 'VMess'),
    'rercvl': ('#&', 'VLess'),
    'rerctr': ('#!', 'Trojan'),
}
DELETE_PREFIXES = {
    'delrcvm': ('###', 'VMess'),
    'delrcvl': ('#&', 'VLess'),
    'delrctr': ('#!', 'Trojan'),
    'delrcss': ('#!!', 'Shadowsocks'),
}

def _list_locked(prefix):
    cmd = f'cat /etc/xray/.lock.db | grep "^{prefix}" | cut -d " " -f 2-3 | sort | uniq | nl'
    return subprocess.check_output(cmd, shell=True).decode("utf-8")

@bot.on(events.CallbackQuery(data=b'recovery'))
async def recovery_menu(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return
    sn = globals().get('STORE_NAME', '🏪 Store')
    ac = globals().get('ADMIN_CONTACT', 'https://t.me/WendiVpn')
    z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
    msg = f"""**◇━━━━━━━━━━◇**
**🔓 RECOVERY MANAGER**
**◇━━━━━━━━━━◇**
{sn}

🌐 **Host** : `{DOMAIN}`
🌍 **ISP** : `{z.get('isp','-')}`
📍 **Lokasi** : `{z.get('country','-')}`
📞 **Admin** : [Hubungi]({ac})
**◇━━━━━━━━━━◇**"""
    await event.edit(msg, buttons=[
        [Button.inline("🔓 Renew VMess", "rercvm"),
         Button.inline("🔓 Renew VLess", "rercvl")],
        [Button.inline("🔓 Renew Trojan", "rerctr")],
        [Button.inline("🗑️ Del VM Lock", "delrcvm"),
         Button.inline("🗑️ Del VL Lock", "delrcvl")],
        [Button.inline("🗑️ Del TR Lock", "delrctr"),
         Button.inline("🗑️ Del SS Lock", "delrcss")],
        [Button.inline("‹ Kembali", "setting")]
    ])

def _make_renew_handler(data_prefix, db_prefix, label):
    @bot.on(events.CallbackQuery(data=bytes(data_prefix, 'utf-8')))
    async def handler(event):
        async def inner(event):
            z = _list_locked(db_prefix)
            await event.respond(f"""**◇━━━━━━━━━━◇**
**🔓 Renew {label}**
**◇━━━━━━━━━━◇**
```
{z}
```""")
            async with bot.conversation(chat) as user:
                await event.respond('**Username Renew:**')
                user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                user = (await user).raw_text.strip()
            async with bot.conversation(chat) as exp:
                await event.respond('**Masa Aktif (hari):**')
                exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = (await exp).raw_text.strip()
            if not user:
                await event.respond(f"❌ **User tidak valid**",
                    buttons=[[Button.inline("‹ Kembali", "recovery")]])
                return
            try:
                subprocess.check_output('renew-lock', shell=True)
                await event.respond(f"✅ **Berhasil Renew** `{user}`",
                    buttons=[[Button.inline("‹ Kembali", "recovery")]])
            except:
                await event.respond(f"❌ **Gagal Renew** `{user}`",
                    buttons=[[Button.inline("‹ Kembali", "recovery")]])
        chat = event.chat_id
        sender = await event.get_sender()
        if valid(str(sender.id)) == "true":
            await inner(event)
        else:
            await event.answer("Akses Ditolak", alert=True)
    return handler

for data_p, db_p, lbl in RECOVERY_PREFIXES.items():
    _make_renew_handler(data_p, db_p, lbl)

def _make_delete_handler(data_prefix, db_prefix, label):
    @bot.on(events.CallbackQuery(data=bytes(data_prefix, 'utf-8')))
    async def handler(event):
        async def inner(event):
            z = _list_locked(db_prefix)
            await event.respond(f"""**◇━━━━━━━━━━◇**
**🗑️ Delete {label} Lock**
**◇━━━━━━━━━━◇**
```
{z}
```""")
            async with bot.conversation(chat) as user:
                await event.respond('**Username:**')
                user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                user = (await user).raw_text.strip()
            if not user:
                await event.respond(f"❌ **Username tidak valid**",
                    buttons=[[Button.inline("‹ Kembali", "recovery")]])
                return
            cmd = f'sed -i "/^{db_prefix} {user}/d" /etc/xray/.lock.db'
            try:
                subprocess.check_output(cmd, shell=True)
                await event.respond(f"✅ **Berhasil Delete** `{user}`",
                    buttons=[[Button.inline("‹ Kembali", "recovery")]])
            except:
                await event.respond(f"❌ **Gagal Delete** `{user}`",
                    buttons=[[Button.inline("‹ Kembali", "recovery")]])
        chat = event.chat_id
        sender = await event.get_sender()
        if valid(str(sender.id)) == "true":
            await inner(event)
        else:
            await event.answer("Akses Ditolak", alert=True)
    return handler

for data_p, db_p, lbl in DELETE_PREFIXES.items():
    _make_delete_handler(data_p, db_p, lbl)
