from kyt import *
import asyncio

@bot.on(events.CallbackQuery(data=b'gen'))
async def create_ip(event):
	chat = event.chat_id
	sender = await event.get_sender()
	async def create_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**ISI IP-YYYY-MM-DD:CONTOH 192.168.1.1-2030-01-30**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text.replace(" ", "")
		msg = await event.respond("**🔄Proses sedang berjalan...**")
		cmd = f'printf "%s\n" "{user}" | bot-link.sh'
		try:
			subprocess.check_output(cmd, shell=True).decode("utf-8")
		except subprocess.CalledProcessError as e:
			await event.respond(f"**Error:** {e.output.decode('utf-8')}")
			return
		await event.respond(f"""
**SUCSESS GENERATE**
**» 🤖@WendiVpn** 
""",buttons=[[Button.inline("‹ Kembali","menu")]])
		await msg.delete()
	a = valid(str(sender.id))
	if a == "true":
		await create_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'regis'))
async def point_ip(event):
	chat = event.chat_id
	sender = await event.get_sender()
	async def point_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**DOMAIN:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text.replace(" ", "")
		async with bot.conversation(chat) as limit_ip:
			await event.respond("**SUBDOMAIN:**")
			limit_ip = limit_ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			limit_ip = (await limit_ip).raw_text.replace(" ", "")
		async with bot.conversation(chat) as pw:
			await event.respond("**IP VPS:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text.replace(" ", "")
			if not re.match(r'^\d+\.\d+\.\d+\.\d+$', pw):
				await event.respond("**IP VPS tidak valid. Gunakan format: 192.168.1.1**", buttons=[
					[Button.inline("🔄 Pointing Ulang","regis")],
					[Button.inline("❌ Batal","setting")]])
				return
		msg = await event.respond("**🔄Proses sedang berjalan...**")
		cmd = f'printf "%s\n" "{user}" "{limit_ip}" "{pw}" | cf.sh'
		try:
			subprocess.check_output(cmd, shell=True).decode("utf-8")
		except subprocess.CalledProcessError as e:
			await event.respond(f"**Error:** {e.output.decode('utf-8')}")
			return
		await event.respond(f"""
**SUCSESS POINTING IP**
**» 🤖@WendiVpn** 
""",buttons=[[Button.inline("‹ Kembali","menu")]])
		await msg.delete()
	a = valid(str(sender.id))
	if a == "true":
		await create_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'reboot'))
async def rebooot(event):
    async def rebooot_(event):
        cmd = 'reboot'
        try:
            result = await asyncio.create_subprocess_shell(cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
            output, _ = await result.communicate()
            output = output.decode('utf-8')
        except Exception as e:
            output = str(e)
        await event.respond(f"""{output}```
**» REBOOT SERVER**
**» 🤖@WendiVpn**
""", buttons=[[Button.inline("‹ Kembali", "menu")]])
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await rebooot_(event)
    else:
        await event.answer("Access Denied", alert=True)

@bot.on(events.CallbackQuery(data=b'resx'))
async def resx(event):
    async def resx_(event):
        msg = await event.respond("**🔄 Proses sedang berjalan...**")
        cmd = 'systemctl restart xray | systemctl restart nginx | systemctl restart haproxy | systemctl restart server | systemctl restart client'
        try:
            result = await asyncio.create_subprocess_shell(cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
            output, _ = await result.communicate()
            output = output.decode('utf-8')
        except Exception as e:
            output = str(e)
        await event.respond(f"""
**» Restarting Service Done**
**» 🤖@WendiVpn**
""", buttons=[[Button.inline("‹ Kembali", "menu")]])
        await msg.delete()
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await resx_(event)
    else:
        await event.answer("Access Denied", alert=True)

@bot.on(events.CallbackQuery(data=b'speedtest'))
async def speedtest(event):
    async def speedtest_(event):
        msg = await event.respond("**🔄 Proses sedang berjalan...**")
        cmd = 'speedtest-cli --share'
        try:
            result = await asyncio.create_subprocess_shell(cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
            output, _ = await result.communicate()
            output = output.decode('utf-8')
        except Exception as e:
            output = str(e)
        await event.respond(f"""
**
{output}
**
**» 🤖@WendiVpn**
""", buttons=[[Button.inline("‹ Kembali", "menu")]])
        await msg.delete()
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await speedtest_(event)
    else:
        await event.answer("Access Denied", alert=True)

@bot.on(events.CallbackQuery(data=b'backup'))
async def backup(event):
    async def backup_(event):
        msg = await event.respond("**🔄 Proses sedang berjalan...**")
        cmd = 'bot-backup'
        subprocess.check_output(cmd, shell=True)
        await event.respond(f"""
**» BACKUP DONE**
**» 🤖@WendiVpn**
""", buttons=[[Button.inline("‹ Kembali", "menu")]])
        await msg.delete()
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await backup_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'restore'))
async def restore(event):
    chat = event.chat_id
    sender = await event.get_sender()
    async def restore_(event):
        nonlocal chat, sender
        async with bot.conversation(chat) as user:
            await event.respond('**Input Link Backup:**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text.replace(" ", "")
            msg = await event.respond("**🔄 Proses sedang berjalan...**")
            cmd = f'printf "%s\n" "{user}" | bot-restore'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
            await event.respond(f"**Successfully**", buttons=[[Button.inline("‹ Kembali", "menu")]])
            await msg.delete()
        except:
            await event.respond(f"**Link Not Found**", buttons=[[Button.inline("‹ Kembali", "menu")]])
            await msg.delete()
    a = valid(str(sender.id))
    if a == "true":
        await restore_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'fixdomain'))
async def fixcert(event):
    async def fixcert_(event):
        msg = await event.respond("**🔄 Proses sedang berjalan...**")
        cmd = 'fixcert'
        subprocess.check_output(cmd, shell=True)
        await event.respond(f"""
**» FIX DOMAIN DONE**
**» 🤖@WendiVpn**
""", buttons=[[Button.inline("‹ Kembali", "menu")]])
        await msg.delete()
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await fixcert_(event)
    else:
        await event.answer("Access Denied", alert=True)

@bot.on(events.CallbackQuery(data=b'host'))
async def addhost(event):
    async def addhost_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Domain:**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text.replace(" ", "")
            msg = await event.respond("**🔄 Proses sedang berjalan...**")
            cmd = f'printf "%s\n" "{user}" | addhost'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond(f"**Domain Gagal**", buttons=[[Button.inline("‹ Kembali", "menu")]])
        else:
            await event.respond(f"**Successfully**", buttons=[[Button.inline("‹ Kembali", "menu")]])
            await msg.delete()
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await addhost_(event)
    else:
        await event.answer("Access Denied", alert=True)

@bot.on(events.CallbackQuery(data=b'auto_delet'))
async def auto_delet(event):
    async def auto_delet_(event):
        msg = await event.respond("**🔄 Proses sedang berjalan...**")
        cmd = 'notif_delet'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""
{z}""")
        async with bot.conversation(chat) as exp:
            await event.respond("**Pilih**",buttons=[
                [Button.inline(" ON ","1"),
                 Button.inline(" OFF ","2")],
                [Button.inline("‹ Kembali", "setting")]])
            exp = exp.wait_event(events.CallbackQuery)
            exp = (await exp).data.decode("ascii")
        cmd = f'printf "%s\n" "{exp}" | auto-delet.sh'
        subprocess.check_output(cmd, shell=True)
        await event.respond(f"""
**» SUKSES SETTING AUTO DEL**
**» 🤖@WendiVpn**
""", buttons=[[Button.inline("‹ Kembali", "menu")]])
        await msg.delete()
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await auto_delet_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'auto_backup'))
async def auto_backup(event):
    async def auto_backup_(event):
        msg = await event.respond("**🔄 Proses sedang berjalan...**")
        cmd = 'notif_backup'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""
{z}""")
        async with bot.conversation(chat) as exp:
            await event.respond("**Pilih**",buttons=[
                [Button.inline(" ON ","1"),
                Button.inline(" OFF ","2")],
                [Button.inline("‹ Kembali", "setting")]])
            exp = exp.wait_event(events.CallbackQuery)
            exp = (await exp).data.decode("ascii")
        cmd = f'printf "%s\n" "{exp}" | auto-backup.sh'
        subprocess.check_output(cmd, shell=True)
        await event.respond(f"""
**» SUKSES SETTING AUTO BACKUP**
**» 🤖@WendiVpn**
""", buttons=[[Button.inline("‹ Kembali", "setting")]])
        await msg.delete()
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await auto_backup_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'limit'))
async def auto_limit(event):
    async def auto_limit_(event):
        msg = await event.respond("**🔄 Proses sedang berjalan...**")
        cmd = 'notif_limit'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""
{z}""")
        async with bot.conversation(chat) as exp:
            await event.respond("**Pilih**",buttons=[
                [Button.inline(" ON ","1"),
                Button.inline(" OFF ","2")]])
            exp = exp.wait_event(events.CallbackQuery)
            exp = (await exp).data.decode("ascii")
        cmd = f'printf "%s\n" "{exp}" | onoff'
        subprocess.check_output(cmd, shell=True)
        await event.respond(f"""
**» SUKSES SETTING LIMIT IP**
**» 🤖@WendiVpn**
""",buttons=[[Button.inline("‹ Kembali", "setting")]])
        await msg.delete()
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await auto_limit_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'addbackup'))
async def add_backup(event):
    async def add_backup_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**TOKEN API:**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text.replace(" ", "")
        async with bot.conversation(chat) as exp:
            await event.respond('**USER ID:**')
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text.replace(" ", "")
            msg = await event.respond("**🔄 Proses sedang berjalan...**")
            cmd = f'printf "%s\n" "{user}" "{exp}" | add-bot-notif'
            subprocess.check_output(cmd, shell=True)
            await event.respond(f"""
**» ADD BOT BACKUP N NOTIF SUKSES**
**» 🤖@WendiVpn**
""",buttons=[[Button.inline("‹ Kembali","menu")]])
        await msg.delete()
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
	if a == "true":
		await point_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'updatebot'))
async def update_bot(event):
    async def update_bot_(event):
        cmd = f'printf "%s\n" "23" | menu'
        await event.respond(f"""
**» UPDATE SCRIPT SUKSES**
**» 🤖@WendiVpn**
""",buttons=[[Button.inline("‹ Kembali","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await update_bot_(event)
    else:
        await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'delbackup'))
async def del_backup(event):
    async def del_backup_(event):
        msg = await event.respond("**🔄 Proses sedang berjalan...**")
        cmd = f'del-bot-notif'
        await event.respond(f"""
**» DELET BOT BACKUP N NOTIF DONE**
**» 🤖@WendiVpn**
""",buttons=[[Button.inline("‹ Kembali","menu")]])
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await del_backup_(event)
    else:
        await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'killtrial'))
async def del_trial(event):
    async def del_trial_(event):
        msg = await event.respond("**🔄 Proses sedang berlangsung, harap tunggu...**")
        cmd = f'xp'
        try:
            output = subprocess.check_output(cmd, shell=True).decode("utf-8")
            await event.respond(f"**Output:**\n```\n{output}\n```\n**» DELET ALL EXPIRED DONE**\n**» 🤖@WendiVpn**", buttons=[[Button.inline("‹ Kembali", "menu")]])
        except subprocess.CalledProcessError as e:
            await event.respond(f"**❌ Error saat menjalankan skrip:** {str(e)}", buttons=[[Button.inline("‹ Kembali", "menu")]])
        await msg.delete()
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await del_trial_(event)
    else:
        await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'backer'))
async def backers(event):
    async def backers_(event):
        inline = [
[Button.inline("➕ Add Backup","addbackup"),
Button.inline("🗑️ Del Backup","delbackup")],
[Button.inline("📦 Backup","backup"),
Button.inline("📥 Restore","restore")],
[Button.inline("‹ Kembali","menu")]]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        username = sender.username
        user_id = sender.id
        msg = f"""
💾 **BACKUP & RESTORE**

🌐 **Host** : `{DOMAIN}`
🆔 **ID** : `{user_id}` | 👤 **@{username}**
"""
        await event.edit(msg,buttons=inline)
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await backers_(event)
    else:
        await event.answer("Access Denied",alert=True)


@bot.on(events.CallbackQuery(data=b'setting'))
async def settings(event):
    async def settings_(event):
        inline = [
[Button.inline("🌐 Limit IP","limit"),
Button.inline("📌 Point IP","regis")],
[Button.inline("🔧 Fix Domain","fixdomain"),
Button.inline("🏠 Domain","host")],
[Button.inline("⏰ Auto Del","auto_delet"),
Button.inline("💾 Auto Backup","auto_backup")],
[Button.inline("🚀 Speedtest","speedtest"),
Button.inline("📦 Backup Restore","backer")],
[Button.inline("🔄 Reboot","reboot"),
Button.inline("🔄 Restart","resx")],
[Button.inline("🗑️ Del Expire","killtrial"),
Button.inline("📝 Regis VPS","regist")],
[Button.inline("🔗 Gen Link","gen"),
Button.inline("💰 Balance","adm-balance")],
[Button.inline("🔓 Del Lock","recovery"),
Button.inline("🌐 Servers","adm-servers")],
[Button.inline("📢 Broadcast","broadcast"),
Button.inline("⚙️ VAR","var-menu")],
[Button.inline("‹ Kembali","menu")]]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        username = sender.username
        user_id = sender.id
        msg = f"""
⚙️ **SETTING MENU**

🌐 **Host** : `{DOMAIN}`
🆔 **ID** : `{user_id}` | 👤 **@{username}**
"""
        await event.edit(msg,buttons=inline)
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await settings_(event)
    else:
        await event.answer("Access Denied",alert=True)

# ── BROADCAST ────────────────────────────────────────────────────────────
@bot.on(events.CallbackQuery(data=b'broadcast'))
async def broadcast(event):
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return
    async with bot.conversation(chat) as conv:
        await event.respond("📢 **Masukkan pesan broadcast:**\n\n_Pesan akan dikirim ke semua user terdaftar._")
        r = conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        msg = (await r).raw_text
    await event.respond("⏳ **Mengirim broadcast...**")
    db = get_db()
    users = db.execute("SELECT telegram_id FROM user_balance").fetchall()
    sent = 0
    failed = 0
    for u in users:
        try:
            await bot.send_message(int(u['telegram_id']),
                f"📢 **BROADCAST**\n\n{msg}\n\n— *Admin*")
            sent += 1
            await asyncio.sleep(0.05)
        except:
            failed += 1
    await event.respond(f"✅ **Broadcast selesai!**\n\n📨 Terkirim: `{sent}`\n❌ Gagal: `{failed}`",
        buttons=[[Button.inline("‹ Kembali","setting")]])

# ── VAR CHANGE ───────────────────────────────────────────────────────────
def _var_path():
    return os.path.join(os.path.dirname(os.path.dirname(__file__)), 'var.txt')

def _update_var(name, val):
    p = _var_path()
    with open(p, 'r') as f:
        lines = f.readlines()
    found = False
    for i, line in enumerate(lines):
        if line.startswith(name + '='):
            lines[i] = f"{name}='{val}'\n"
            found = True
            break
    if not found:
        lines.append(f"{name}='{val}'\n")
    with open(p, 'w') as f:
        f.writelines(lines)
    globals()[name] = val

@bot.on(events.CallbackQuery(data=b'var-menu'))
async def var_menu(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return
    await event.edit("**⚙️ VARIABLE SETTINGS**\n\n"
        "Gunakan menu untuk mengubah variabel bot.\n\n"
        "⚠️ Setelah mengubah **BOT_TOKEN** atau **ADMIN**, restart bot diperlukan.",
        buttons=[
            [Button.inline("🤖 BOT_TOKEN","var-token")],
            [Button.inline("👤 ADMIN","var-admin")],
            [Button.inline("💳 BAYARGG_API_KEY","var-bayar")],
            [Button.inline("📞 CALLBACK_HOST","var-callback")],
            [Button.inline("‹ Kembali","setting")]])

@bot.on(events.CallbackQuery(func=lambda e: e.data.startswith(b'var-')))
async def var_change(event):
    data = event.data.decode()
    parts = data.split('-', 1)
    if len(parts) < 2 or parts[1] == 'menu':
        return
    var_type = parts[1]
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return
    var_map = {
        'token': ('BOT_TOKEN', '🤖 **Masukkan BOT_TOKEN baru:**'),
        'admin': ('ADMIN', '👤 **Masukkan ADMIN ID baru:** (numeric)'),
        'bayar': ('BAYARGG_API_KEY', '💳 **Masukkan BAYARGG_API_KEY baru:**'),
        'callback': ('CALLBACK_HOST', '📞 **Masukkan CALLBACK_HOST baru:**'),
    }
    if var_type not in var_map:
        return
    var_name, prompt = var_map[var_type]
    async with bot.conversation(chat) as conv:
        await event.respond(prompt)
        r = conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        val = (await r).raw_text.strip()
    if not val:
        await event.respond("❌ **Nilai tidak boleh kosong.**",
            buttons=[[Button.inline("‹ Kembali","var-menu")]])
        return
    try:
        _update_var(var_name, val)
        await event.respond(f"✅ **{var_name} berhasil diubah!**\n\nNilai baru: `{val}`",
            buttons=[[Button.inline("‹ Kembali","var-menu")]])
    except Exception as e:
        await event.respond(f"❌ **Gagal:** `{e}`",
            buttons=[[Button.inline("‹ Kembali","var-menu")]])
