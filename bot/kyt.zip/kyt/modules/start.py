from kyt import *

@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
	await menu(event)





