from kyt import *

@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
    from kyt.modules.menu import menu
    await menu(event)
