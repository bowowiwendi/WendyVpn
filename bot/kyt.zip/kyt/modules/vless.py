from kyt import *
from kyt.modules.server_manager import exec_cmd, get_active, get_server

#detail
@bot.on(events.CallbackQuery(data=b'd-vless'))
async def l_vless(event):
    async def l_vless_(event):
        cmd = 'cat /etc/xray/config.json | grep "^#&" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
        x = exec_cmd(cmd, tid)
        z = x.decode("utf-8")
        await event.respond(f"""
**◇━━━━━━━━━━◇**
    ** ⟨🔸 Vless Account🔸⟩**
**◇━━━━━━━━━━◇**
```
{z}
```
""")
        async with bot.conversation(chat) as user:
            await event.respond(" **🔡Username:**")
            user_event = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user_event).raw_text.replace(" ", "")
            cmd_check = f'cat /etc/xray/config.json | grep "{user}"'
            if subprocess.call(cmd_check, shell=True) != 0:
                await event.respond("**Username tidak ditemukan. Silakan masukkan username yang benar.**", buttons=[
[Button.inline("🔄 Ulangi","d-vless")],
[Button.inline("❌ Batal","vless")]])
                return
            cmd = f'cat /var/www/html/vless-{user}.txt'.strip()
            x = exec_cmd(cmd, tid)
            z = x.decode("utf-8")
            if z:
                await event.respond(f"""
**◇━━━━━━━━━━◇**
    ** ⟨🔸 Vless Account🔸⟩**
**◇━━━━━━━━━━◇**
```
{z}
```
""",buttons=[[Button.inline("‹ Kembali","vless")]])
            else:
                await event.respond("**Filed**: User tidak ditemukan", buttons=[[Button.inline("‹ Kembali","vless")]])
    chat = event.chat_id
    sender = await event.get_sender()
    tid = str(sender.id)
    a = valid(str(sender.id))
    if a == "true":
        await l_vless_(event)
    else:
        await event.answer("Akses Ditolak",alert=True)

#LOCK vless
@bot.on(events.CallbackQuery(data=b'lock-vless'))
async def lock_vless(event):
    chat = event.chat_id
    sender = await event.get_sender()
    tid = str(sender.id)
    a = valid(str(sender.id))
    if a != "true":
        await event.answer("Akses Ditolak",alert=True)
        return
    async def lock_vless_(event):
        cmd = 'cat /etc/xray/config.json | grep "^#&" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
        x = exec_cmd(cmd, tid)
        z = x.decode("utf-8")
        await event.respond(f"""
**◇━━━━━━━━━━◇**
    ** ⟨🔸 Vless Account🔸⟩**
**◇━━━━━━━━━━◇**
```
{z}
```
""")
        async with bot.conversation(chat) as user:
            await event.respond(" **🔡Username:**")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text.replace(" ", "")
            cmd = f'printf "%s\n" "{user}" | lock-vl'
        try:
            a = exec_cmd(cmd, tid).decode("utf-8")
        except subprocess.CalledProcessError:
            await event.respond(f" **Successfully**", buttons=[[Button.inline("‹ Kembali","vless")]])
        else:
            await event.respond(f" **Successfully Lock**", buttons=[[Button.inline("‹ Kembali","vless")]])
    await lock_vless_(event)

#UNLOCK vless
@bot.on(events.CallbackQuery(data=b'unlock-vless'))
async def unlock_vless(event):
    chat = event.chat_id
    sender = await event.get_sender()
    tid = str(sender.id)
    a = valid(str(sender.id))
    if a != "true":
        await event.answer("Akses Ditolak",alert=True)
        return
    async def unlock_vless_(event):
        cmd = 'cat /etc/xray/.lock.db | grep "^#&" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
        x = exec_cmd(cmd, tid)
        z = x.decode("utf-8")
        await event.respond(f"""
**◇━━━━━━━━━━◇**
    ** ⟨🔸 Vless Account🔸⟩**
**◇━━━━━━━━━━◇**
```
{z}
```
""")
        async with bot.conversation(chat) as user:
            await event.respond(" **🔡Username:**")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text.replace(" ", "")
            cmd = f'printf "%s\n" "{user}" | unlock-vl'
        try:
            a = exec_cmd(cmd, tid).decode("utf-8")
        except subprocess.CalledProcessError:
            await event.respond(f" **Successfully**", buttons=[[Button.inline("‹ Kembali","vless")]])
        else:
            await event.respond(f" **Successfully Unlock**", buttons=[[Button.inline("‹ Kembali","vless")]])
    await unlock_vless_(event)

@bot.on(events.CallbackQuery(data=b'create-vless'))
async def create_vless(event):
    chat = event.chat_id
    sender = await event.get_sender()
    tid = str(sender.id)
    a = valid(str(sender.id))
    if a != "true":
        await event.answer("Akses Ditolak",alert=True)
        return
    svr_label = ""
    svr_id = get_active(tid)
    if svr_id is not None:
        s = get_server(svr_id)
        if s:
            svr_label = f"\n**📍 Remote:** `{s['name']}`"
    async def create_vless_(event):
        nonlocal svr_label
        async with bot.conversation(chat) as user:
            await event.respond('🔡 **Username:**\nKetik `random` untuk username acak')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text.replace(" ", "")
        random_user = False
        if user.lower() == "random":
            user = "user" + str(random.randint(1000, 9999))
            random_user = True
        async with bot.conversation(chat) as limit_ip:
            await event.respond("🌐 **Limit IP:**")
            limit_ip = limit_ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            limit_ip = (await limit_ip).raw_text
            if not limit_ip.isdigit():
                await event.respond("🌐 **Limit IP harus berupa angka.**", buttons=[
[Button.inline("🔄 Create Ulang","create-vless")],
[Button.inline("❌ Batal","vless")]])
                return
        async with bot.conversation(chat) as pw:
            await event.respond("📦 **Quota:**")
            pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            pw = (await pw).raw_text
            if not pw.isdigit():
                await event.respond("📦 **Quota harus berupa angka.**", buttons=[
[Button.inline("🔄 Create Ulang","create-vless")],
[Button.inline("❌ Batal","vless")]])
                return
        async with bot.conversation(chat) as exp:
            await event.respond("⏳ **Masaaktif:**")
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text
            if not exp.isdigit():
                await event.respond("⏳ **Masaaktif harus berupa angka.**", buttons=[
[Button.inline("🔄 Create Ulang","create-vless")],
[Button.inline("❌ Batal","vless")]])
                return
        bug = ""
        done = False
        for attempt in range(5 if random_user else 1):
            cmd = f'printf "%s\n" "{user}" "{limit_ip}" "{pw}" "{exp}" "{bug}" | addvless'
            try:
                a = exec_cmd(cmd, tid).decode("utf-8")
                done = True
                break
            except:
                if random_user:
                    user = "user" + str(random.randint(1000, 9999))
                else:
                    break
        if not done:
            await event.respond("**Gagal membuat akun. Coba lagi.**",buttons=[[Button.inline("‹ Kembali","vless")]])
            return
        else:
            inline=[[Button.inline("‹ Kembali","vless")]]
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp))
            x = [x.group() for x in re.finditer("vless://(.*)",a)]
            print(x)
            uuid = re.search("vless://(.*?)@",x[0]).group(1)
            msg = f"""
**◇━━━━━━━━━━◇**
        **⚡️ Xray/Vless Account ⚡️**
**◇━━━━━━━━━━◇**
**» Remarks     :** `{user}`
**» Host Server :** `{DOMAIN}`
**» Limit IP    :** `{limit_ip}`
**» User Quota  :** `{pw} GB`
**» Port DNS    :** `443, 53`
**» port TLS    :** `222-1000`
**» Port NTLS   :** `80, 8080, 8081-9999`
**» NetWork     :** `(WS) or (gRPC)`
**» User ID     :** `{uuid}`
**» Path Vless  :** `(/multi path)/vless `
**» Path Dynamic:** `http://BUG.COM/vless `
**◇━━━━━━━━━━◇**
**» Link TLS   : **
```{x[0]}```
**◇━━━━━━━━━━◇**
**» Link GRPC  :**
```{x[2].replace(" ","")}```
**◇━━━━━━━━━━◇**
**» Format OpenClash :** 
https://{DOMAIN}:81/vless-{user}.txt
**◇━━━━━━━━━━◇**
**» 📎 Link:** [Klik disini](https://{DOMAIN}:81/vless-{user}.txt)
**◇━━━━━━━━━━◇**
**» Expired Until:** `{later}`
{svr_label}
**» 🤖@WendiVpn**
"""
            qr_path = generate_qr(x[0].replace(" ",""), "vless")
            await bot.send_file(event.chat_id, qr_path, caption=msg, buttons=inline)
            os.unlink(qr_path)
    await create_vless_(event)

@bot.on(events.CallbackQuery(data=b'auto-vless'))
async def auto_vless(event):
    chat = event.chat_id
    sender = await event.get_sender()
    tid = str(sender.id)
    a = valid(str(sender.id))
    if a != "true":
        await event.answer("Akses Ditolak",alert=True)
        return
    svr_label = ""
    svr_id = get_active(tid)
    if svr_id is not None:
        s = get_server(svr_id)
        if s:
            svr_label = f"\n**📍 Remote:** `{s['name']}`"
    async def auto_vless_(event):
        nonlocal svr_label
        async with bot.conversation(chat) as limit_ip:
            await event.respond("🌐 **Limit IP:**")
            limit_ip = limit_ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            limit_ip = (await limit_ip).raw_text
            if not limit_ip.isdigit():
                await event.respond("🌐 **Limit IP harus berupa angka.**", buttons=[
[Button.inline("🔄 Create Ulang","create-vless")],
[Button.inline("❌ Batal","vless")]])
                return
        async with bot.conversation(chat) as pw:
            await event.respond("📦 **Quota:**")
            pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            pw = (await pw).raw_text
            if not pw.isdigit():
                await event.respond("📦 **Quota harus berupa angka.**", buttons=[
[Button.inline("🔄 Create Ulang","create-vless")],
[Button.inline("❌ Batal","vless")]])
                return
        async with bot.conversation(chat) as exp:
            await event.respond("⏳ **Masaaktif:**")
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text
            if not exp.isdigit():
                await event.respond("⏳ **Masaaktif harus berupa angka.**", buttons=[
[Button.inline("🔄 Create Ulang","create-vless")],
[Button.inline("❌ Batal","vless")]])
                return
        bug = ""
        user = "VlessPrem"+str(random.randint(100,1000))
        cmd = f'printf "%s\n" "{user}" "{limit_ip}" "{pw}" "{exp}" "{bug}" | addvless'
        try:
            a = exec_cmd(cmd, tid).decode("utf-8")
        except:
            await event.respond("**User Already Exist**")
        else:
            inline=[[Button.inline("‹ Kembali","vless")]]
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp))
            x = [x.group() for x in re.finditer("vless://(.*)",a)]
            print(x)
            uuid = re.search("vless://(.*?)@",x[0]).group(1)
            msg = f"""
**◇━━━━━━━━━━◇**
        **⚡️ Xray/Vless Account ⚡️**
**◇━━━━━━━━━━◇**
**» Remarks     :** `{user}`
**» Host Server :** `{DOMAIN}`
**» Limit IP    :** `{limit_ip}`
**» User Quota  :** `{pw} GB`
**» Port DNS    :** `443, 53`
**» port TLS    :** `222-1000`
**» Port NTLS   :** `80, 8080, 8081-9999`
**» NetWork     :** `(WS) or (gRPC)`
**» User ID     :** `{uuid}`
**» Path Vless  :** `(/multi path)/vless `
**» Path Dynamic:** `http://BUG.COM/vless `
**◇━━━━━━━━━━◇**
**» Link TLS   : **
```{x[0]}```
**◇━━━━━━━━━━◇**
**» Link GRPC  :**
```{x[2].replace(" ","")}```
**◇━━━━━━━━━━◇**
**» Format OpenClash :** 
https://{DOMAIN}:81/vless-{user}.txt
**◇━━━━━━━━━━◇**
**» Expired Until:** `{later}`
{svr_label}
**» 🤖@WendiVpn**
"""
            await event.respond(msg,buttons=inline)
    await auto_vless_(event)

@bot.on(events.CallbackQuery(data=b'cek-vless'))
async def cek_vless(event):
    async def cek_vless_(event):
        cmd = 'bot-cek-vless'.strip()
        x = exec_cmd(cmd, tid)
        z = x.decode("utf-8")
        await event.respond(f"""
**◇━━━━━━━━━━◇**
    ** ⟨🔸 Vless Logged🔸⟩**
**◇━━━━━━━━━━◇**
```                      
{z}
```
**Shows Logged In Users Vless**
**» 🤖@WendiVpn**
""",buttons=[[Button.inline("‹ Kembali","vless")]])
    sender = await event.get_sender()
    tid = str(sender.id)
    a = valid(str(sender.id))
    if a == "true":
        await cek_vless_(event)
    else:
        await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'delete-vless'))
async def delete_vless(event):
    chat = event.chat_id
    sender = await event.get_sender()
    tid = str(sender.id)
    a = valid(str(sender.id))
    if a != "true":
        await event.answer("Akses Ditolak",alert=True)
        return
    async def delete_vless_(event):
        cmd = 'cat /etc/xray/config.json | grep "^#&" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
        x = exec_cmd(cmd, tid)
        z = x.decode("utf-8")
        await event.respond(f"""
**◇━━━━━━━━━━◇**
    ** ⟨🔸 Vless Account🔸⟩**
**◇━━━━━━━━━━◇**
```
{z}
```
""")
        async with bot.conversation(chat) as user:
            await event.respond(' **🔡Username:**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text.replace(" ", "")
            cmd = f'printf "%s\n" "{user}" | delvless'
        try:
            a = exec_cmd(cmd, tid).decode("utf-8")
        except subprocess.CalledProcessError:
            await event.respond(f" **Successfully**", buttons=[[Button.inline("‹ Kembali","vless")]])
        else:
            await event.respond(f" **Successfully Delet**", buttons=[[Button.inline("‹ Kembali","vless")]])
    await delete_vless_(event)

@bot.on(events.CallbackQuery(data=b'trial-vless'))
async def trial_vless(event):
    chat = event.chat_id
    sender = await event.get_sender()
    tid = str(sender.id)
    a = valid(str(sender.id))
    if a != "true":
        await event.answer("Akses Ditolak",alert=True)
        return
    svr_label = ""
    svr_id = get_active(tid)
    if svr_id is not None:
        s = get_server(svr_id)
        if s:
            svr_label = f"\n**📍 Remote:** `{s['name']}`"
    async def trial_vless_(event):
        nonlocal svr_label
        async with bot.conversation(chat) as exp:
            await event.respond("**Choose Expiry Minutes**",buttons=[
[Button.inline(" 10 Menit ","10"),
Button.inline(" 15 Menit ","15")],
[Button.inline(" 30 Menit ","30"),
Button.inline(" 60 Menit ","60")]])
            exp = exp.wait_event(events.CallbackQuery)
            exp = (await exp).data.decode("ascii")
        cmd = f'printf "%s\n" "{exp}" | trialvless'
        try:
            a = exec_cmd(cmd, tid).decode("utf-8")
        except:
            await event.respond("**User Already Exist**")
        else:
            inline=[[Button.inline("‹ Kembali","vless")]]
            x = [x.group() for x in re.finditer("vless://(.*)",a)]
            print(x)
            remarks = re.search("#(.*)",x[0]).group(1)
            uuid = re.search("vless://(.*?)@",x[0]).group(1)
            msg = f"""
**◇━━━━━━━━━━◇**
        **⚡️ Xray/Vless Account ⚡️**
**◇━━━━━━━━━━◇**
**» Remarks     :** `{remarks}`
**» Host Server :** `{DOMAIN}`
**» User Quota  :** `Unlimited`
**» Port DNS    :** `443, 53`
**» port TLS    :** `222-1000`
**» Port NTLS   :** `80, 8080, 8081-9999`
**» NetWork     :** `(WS) or (gRPC)`
**» User ID     :** `{uuid}`
**» Path Vless  :** `(/multi path)/vless `
**» Path Dynamic:** `http://BUG.COM/vless `
**◇━━━━━━━━━━◇**
**» Link TLS   : **
```{x[0]}```
**◇━━━━━━━━━━◇**
**» Link GRPC  :**
```{x[2].replace(" ","")}```
**◇━━━━━━━━━━◇**
**» Format OpenClash :** 
https://{DOMAIN}:81/vless-{remarks}.txt
**◇━━━━━━━━━━◇**
**» Expired Until :** `{exp} Minutes`
{svr_label}
**» 🤖@WendiVpn**
"""
            await event.respond(msg,buttons=inline)
    await trial_vless_(event)

@bot.on(events.CallbackQuery(data=b'bot-member-vl'))
async def bot_member_vl(event):
    async def bot_member_vl_(event):
        cmd = 'cat /etc/xray/config.json | grep "^#&" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
        x = exec_cmd(cmd, tid)
        z = x.decode("utf-8")
        await event.respond(f"""
**◇━━━━━━━━━━◇**
    ** ⟨🔸 Vless Account🔸⟩**
**◇━━━━━━━━━━◇**
```
{z}
```
**Menampilkan Member Vless**
**» 🤖@WendiVpn**
""",buttons=[[Button.inline("‹ Kembali","vless")]])
    sender = await event.get_sender()
    tid = str(sender.id)
    a = valid(str(sender.id))
    if a == "true":
        await bot_member_vl_(event)
    else:
        await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'renew-vl'))
async def renew_vl(event):
    chat = event.chat_id
    sender = await event.get_sender()
    tid = str(sender.id)
    a = valid(str(sender.id))
    if a != "true":
        await event.answer("Akses Ditolak",alert=True)
        return
    async def renew_vl_(event):
        cmd = 'cat /etc/xray/config.json | grep "^#&" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
        x = exec_cmd(cmd, tid)
        z = x.decode("utf-8")
        await event.respond(f"""
**◇━━━━━━━━━━◇**
    ** ⟨🔸 Vless Account🔸⟩**
**◇━━━━━━━━━━◇**
```
{z}
```
""")
        async with bot.conversation(chat) as user:
            await event.respond(' **🔡Username Renew:**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text.replace(" ", "")
        async with bot.conversation(chat) as exp:
            await event.respond(' **Ubah Masaaktif:**')
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text
            if not exp.isdigit():
                await event.respond(" **Masaaktif harus berupa angka.**", buttons=[
[Button.inline("🔄 Renew Ulang","renew-ws")],
[Button.inline("❌ Batal","vless")]])
                return
        async with bot.conversation(chat) as quota:
            await event.respond(' **Limit Quota:**')
            quota = quota.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            quota = (await quota).raw_text
            if not quota.isdigit():
                await event.respond(" **Limit Quota harus berupa angka.**", buttons=[
[Button.inline("🔄 Renew Ulang","renew-ws")],
[Button.inline("❌ Batal","vless")]])
                return
        async with bot.conversation(chat) as ip:
            await event.respond(' **Limit Ip:**')
            ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            ip = (await ip).raw_text
            if not ip.isdigit():
                await event.respond(" **Limit Ip harus berupa angka.**", buttons=[
[Button.inline("🔄 Renew Ulang","renew-ws")],
[Button.inline("❌ Batal","vless")]])
                return
            cmd = f'printf "%s\n" "{user}" "{exp}" "{quota}" "{ip}" | renewvless'
        try:
            a = exec_cmd(cmd, tid).decode("utf-8")
        except:
            await event.respond(f"**User** `{user}` **Successfully**",buttons=[[Button.inline("‹ Kembali","vless")]])
        else:
            await event.respond(f"**Successfully Renew** `{user}`",buttons=[[Button.inline("‹ Kembali","vless")]])
    await renew_vl_(event)


@bot.on(events.CallbackQuery(data=b'vless'))
async def vless(event):
    async def vless_(event):
        inline = [
[Button.inline("⚡️ Auto Vless","auto-vless")],
[Button.inline("☣️ Trial","trial-vless"),
Button.inline("➕ Create","create-vless")],
[Button.inline("♻️ Renew","renew-vl"),
Button.inline("👤 Member","bot-member-vl")],
[Button.inline("✅ Check","cek-vless"),
Button.inline("❌ Delete","delete-vless")],
[Button.inline("🔒 Lock","lock-vless"),
Button.inline("🔐 Unlock","unlock-vless")],
[Button.inline("📝 Detail","d-vless")],
[Button.inline("‹ Kembali","menu")]]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        vl = f' cat /etc/vless/.vless.db | grep "###" | wc -l'
        vls = exec_cmd(vl, tid).decode("ascii")
        username = sender.username
        user_id = sender.id
        msg = f"""
🔷 **VLESS MANAGER**

🌐 **Host** : `{DOMAIN}`
📊 **Total** : `{vls.strip()}` akun
🆔 **ID** : `{user_id}` | 👤 **@{username}**
"""
        await event.edit(msg,buttons=inline)
    sender = await event.get_sender()
    tid = str(sender.id)
    a = valid(str(sender.id))
    if a == "true":
        await vless_(event)
    else:
        await event.answer("Access Denied",alert=True)
