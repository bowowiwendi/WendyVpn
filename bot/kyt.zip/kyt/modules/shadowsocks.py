from kyt import *
from kyt.modules.server_manager import exec_cmd, get_active, get_server

#LOCK ss
@bot.on(events.CallbackQuery(data=b'lock-ss'))
async def lock_ss(event):
    chat = event.chat_id
    sender = await event.get_sender()
    tid = str(sender.id)
    a = valid(str(sender.id))
    if a != "true":
        await event.answer("Akses Ditolak",alert=True)
        return
    async def lock_ss_(event):
        cmd = 'cat /etc/xray/config.json | grep "^#!!" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
        x = exec_cmd(cmd, tid)
        print(x)
        z = exec_cmd(cmd, tid).decode("utf-8")
        await event.respond(f"""
◇━━━━━━━━━━━━━━━━◇
    ** ⟨🔸 SS Account🔸⟩**
◇━━━━━━━━━━━━━━━━◇
```
{z}
```
""")
        async with bot.conversation(chat) as user:
            await event.respond(" **🔡Username:**")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text.replace(" ", "")
            cmd_check = f'grep "^#!! {user} " /etc/xray/config.json'
            if subprocess.call(cmd_check, shell=True) != 0:
                await event.respond("**Username tidak ditemukan.**", buttons=[
                    [Button.inline("🔄 Ulangi", "lock-ss")],
                    [Button.inline("❌ Batal", "shadowsocks")]])
                return
            cmd = f'printf "%s\n" "{user}" | lock-ss'
        try:
            a = exec_cmd(cmd, tid).decode("utf-8")
        except subprocess.CalledProcessError:
            await event.respond(f" **Successfully**", buttons=[[Button.inline("‹ Kembali","shadowsocks")]])
        else:
            await event.respond(f" **Successfully Lock**", buttons=[[Button.inline("‹ Kembali","shadowsocks")]])
    await lock_ss_(event)

#UNLOCK ss
@bot.on(events.CallbackQuery(data=b'unlock-ss'))
async def unlock_ss(event):
    chat = event.chat_id
    sender = await event.get_sender()
    tid = str(sender.id)
    a = valid(str(sender.id))
    if a != "true":
        await event.answer("Akses Ditolak",alert=True)
        return
    async def unlock_ss_(event):
        cmd = 'cat /etc/xray/.lock.db | grep "^#!!" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
        x = exec_cmd(cmd, tid)
        print(x)
        z = exec_cmd(cmd, tid).decode("utf-8")
        await event.respond(f"""
◇━━━━━━━━━━━━━━━━◇
    ** ⟨🔸 SS Account🔸⟩**
◇━━━━━━━━━━━━━━━━◇
```
{z}
```
""")
        async with bot.conversation(chat) as user:
            await event.respond(" **🔡Username:**")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text.replace(" ", "")
            cmd_check = f'grep "^#!! {user} " /etc/xray/config.json'
            if subprocess.call(cmd_check, shell=True) != 0:
                await event.respond("**Username tidak ditemukan.**", buttons=[
                    [Button.inline("🔄 Ulangi", "unlock-ss")],
                    [Button.inline("❌ Batal", "shadowsocks")]])
                return
            cmd = f'printf "%s\n" "{user}" | unlock-ss'
        try:
            a = exec_cmd(cmd, tid).decode("utf-8")
        except subprocess.CalledProcessError:
            await event.respond(f" **Successfully**", buttons=[[Button.inline("‹ Kembali","shadowsocks")]])
        else:
            await event.respond(f" **Successfully Unlock**", buttons=[[Button.inline("‹ Kembali","shadowsocks")]])
    await unlock_ss_(event)

#detail
@bot.on(events.CallbackQuery(data=b'd-ss'))
async def l_ss(event):
    async def l_ss_(event):
        cmd = 'cat /etc/xray/config.json | grep "^#!!" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
        x = exec_cmd(cmd, tid)
        print(x)
        z = exec_cmd(cmd, tid).decode("utf-8")
        await event.respond(f"""
◇━━━━━━━━━━━━━━━━◇
    ** ⟨🔸 Shadowsocks Account🔸⟩**
◇━━━━━━━━━━━━━━━━◇
```
{z}
```
""")
        async with bot.conversation(chat) as user:
            await event.respond(" **🔡Username:**")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text.replace(" ", "")
            cmd = f'cat /var/www/html/sodosokws-{user}.txt'.strip()
            x = exec_cmd(cmd, tid)
            print(x)
            z = exec_cmd(cmd, tid).decode("utf-8")
            if z:
                await event.respond(f"""
◇━━━━━━━━━━━━━━━━◇
    ** ⟨🔸 Shadowsocks Account🔸⟩**
◇━━━━━━━━━━━━━━━━◇
```
{z}
```
""",buttons=[[Button.inline("‹ Kembali","shadowsocks")]])
            else:
                await event.respond("**Filed**: User tidak ditemukan", buttons=[[Button.inline("‹ Kembali","shadowsocks")]])
    chat = event.chat_id
    sender = await event.get_sender()
    tid = str(sender.id)
    a = valid(str(sender.id))
    if a == "true":
        await l_ss_(event)
    else:
        await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'create-shadowsocks'))
async def create_shadowsocks(event):
    chat = event.chat_id
    sender = await event.get_sender()
    tid = str(sender.id)
    a = valid(str(sender.id))
    if a != "true":
        await event.answer("Akses Ditolak",alert=True)
        return
    svr_label = ""
    svr_id = get_active(tid)
    if svr_id is not None:
        s = get_server(svr_id)
        if s:
            svr_label = f"\n**📍 Remote:** `{s['name']}`"
    async def create_shadowsocks_(event):
        nonlocal svr_label
        random_user = False
        async with bot.conversation(chat) as user:
            await event.respond('🔡 **Username:**\nEnter = random, atau ketik username')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text.replace(" ", "")
        if not user or user.lower() == "random":
            user = "user" + str(random.randint(1000, 9999))
            random_user = True
        async with bot.conversation(chat) as limit_ip:
            await event.respond("🌐 **Limit IP:**")
            limit_ip = limit_ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            limit_ip = (await limit_ip).raw_text
            if not limit_ip.isdigit():
                await event.respond("🌐 **Limit IP harus berupa angka.**", buttons=[
[Button.inline("🔄 Create Ulang","create-shadowsocks")],
[Button.inline("❌ Batal","shadowsocks")]])
                return
        async with bot.conversation(chat) as pw:
            await event.respond("📦 **Quota:**")
            pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            pw = (await pw).raw_text
            if not pw.isdigit():
                await event.respond("📦 **Quota harus berupa angka.**", buttons=[
[Button.inline("🔄 Create Ulang","create-shadowsocks")],
[Button.inline("❌ Batal","shadowsocks")]])
                return
        async with bot.conversation(chat) as exp:
            await event.respond("⏳ **Masaaktif:**")
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text
            if not exp.isdigit():
                await event.respond("⏳ **Masaaktif harus berupa angka.**", buttons=[
[Button.inline("🔄 Create Ulang","create-shadowsocks")],
[Button.inline("❌ Batal","shadowsocks")]])
                return
        bug = ""
        done = False
        for attempt in range(5 if random_user else 1):
            cmd = f'printf "%s\n" "{user}" "{limit_ip}" "{exp}" "{pw}" "{bug}" | addss'
            try:
                a = exec_cmd(cmd, tid).decode("utf-8")
                done = True
                break
            except:
                if random_user:
                    user = "user" + str(random.randint(1000, 9999))
                else:
                    break
        if not done:
            await event.respond("**Gagal membuat akun.**", buttons=[
[Button.inline("🔄 Create Ulang","create-shadowsocks")],
[Button.inline("❌ Batal","shadowsocks")]])
            return
        inline=[[Button.inline("‹ Kembali","menu")]]
        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        x = [x.group() for x in re.finditer("ss://(.*)",a)]
        print(x)
        uuid = re.search("ss://(.*?)@",x[0]).group(1)
        msg = f"""
🌑 **SHADOWSOCKS ACCOUNT**

👤 **Username** : `{user}`
🌐 **Host** : `{DOMAIN}`
📱 **Limit IP** : `{limit_ip}`
📦 **Quota** : `Unlimited`
⏳ **Expired** : `{later}`

◇━━━━━━━━━━━━━━━━◇
🔗 **TLS** : `{x[0]}`
🔗 **gRPC** : `{x[2].replace(" ","")}`
💾 **OpenClash** : [Klik Disini](https://{DOMAIN}:81/oc-sodosokws-{user}.txt)
{svr_label}
"""
        qr_path = generate_qr(x[0].replace(" ",""), "ss")
        await bot.send_file(event.chat_id, qr_path, caption=msg, buttons=inline)
        os.unlink(qr_path)
    await create_shadowsocks_(event)

@bot.on(events.CallbackQuery(data=b'auto-shadowsocks'))
async def auto_shadowsocks(event):
    chat = event.chat_id
    sender = await event.get_sender()
    tid = str(sender.id)
    a = valid(str(sender.id))
    if a != "true":
        await event.answer("Akses Ditolak",alert=True)
        return
    svr_label = ""
    svr_id = get_active(tid)
    if svr_id is not None:
        s = get_server(svr_id)
        if s:
            svr_label = f"\n**📍 Remote:** `{s['name']}`"
    async def auto_shadowsocks_(event):
        nonlocal svr_label
        async with bot.conversation(chat) as limit_ip:
            await event.respond("🌐 **Limit IP:**")
            limit_ip = limit_ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            limit_ip = (await limit_ip).raw_text
            if not limit_ip.isdigit():
                await event.respond("🌐 **Limit IP harus berupa angka.**", buttons=[
[Button.inline("🔄 Auto Ulang","auto-shadowsocks")],
[Button.inline("❌ Batal","shadowsocks")]])
                return
        async with bot.conversation(chat) as pw:
            await event.respond("📦 **Quota:**")
            pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            pw = (await pw).raw_text
            if not pw.isdigit():
                await event.respond("📦 **Quota harus berupa angka.**", buttons=[
[Button.inline("🔄 Auto Ulang","auto-shadowsocks")],
[Button.inline("❌ Batal","shadowsocks")]])
                return
        async with bot.conversation(chat) as exp:
            await event.respond("⏳ **Masaaktif:**")
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text
            if not exp.isdigit():
                await event.respond("⏳ **Masaaktif harus berupa angka.**", buttons=[
[Button.inline("🔄 Auto Ulang","auto-shadowsocks")],
[Button.inline("❌ Batal","shadowsocks")]])
                return
        bug = ""
        user = "ShadowPrem"+str(random.randint(100,1000))
        cmd = f'printf "%s\n" "{user}" "{limit_ip}" "{exp}" "{pw}" "{bug}" | addss'
        try:
            a = exec_cmd(cmd, tid).decode("utf-8")
        except:
            await event.respond("**User Already Exist**")
        else:
            inline=[[Button.inline("‹ Kembali","menu")]]
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp))
            x = [x.group() for x in re.finditer("ss://(.*)",a)]
            print(x)
            uuid = re.search("ss://(.*?)@",x[0]).group(1)
            msg = f"""
🌑 **SHADOWSOCKS ACCOUNT**

👤 **Username** : `{user}`
🌐 **Host** : `{DOMAIN}`
📱 **Limit IP** : `{limit_ip}`
📦 **Quota** : `Unlimited`
⏳ **Expired** : `{later}`

◇━━━━━━━━━━━━━━━━◇
🔗 **TLS** : `{x[0]}`
🔗 **gRPC** : `{x[2].replace(" ","")}`
💾 **OpenClash** : [Klik Disini](https://{DOMAIN}:81/oc-sodosokws-{user}.txt)
{svr_label}
"""
            await event.respond(msg,buttons=inline)
    await auto_shadowsocks_(event)

@bot.on(events.CallbackQuery(data=b'cek-shadowsocks'))
async def cek_shadowsocks(event):
    async def cek_shadowsocks_(event):
        cmd = 'bot-cek-ss'.strip()
        x = exec_cmd(cmd, tid)
        print(x)
        z = exec_cmd(cmd, tid).decode("utf-8")
        await event.respond(f"""
◇━━━━━━━━━━━━━━━━◇
    ** ⟨🔸 Shadowsocks Logged🔸⟩**
◇━━━━━━━━━━━━━━━━◇
```                      
{z}
```
**Shows Logged In Users Shadowsocks**
» 🤖 @WendiVpn
""",buttons=[[Button.inline("‹ Kembali","menu")]])
    sender = await event.get_sender()
    tid = str(sender.id)
    a = valid(str(sender.id))
    if a == "true":
        await cek_shadowsocks_(event)
    else:
        await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'delete-shadowsocks'))
async def delete_shadowsocks(event):
    chat = event.chat_id
    sender = await event.get_sender()
    tid = str(sender.id)
    a = valid(str(sender.id))
    if a != "true":
        await event.answer("Akses Ditolak",alert=True)
        return
    async def delete_shadowsocks_(event):
        cmd = 'cat /etc/xray/config.json | grep "^#!!" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
        x = exec_cmd(cmd, tid)
        print(x)
        z = exec_cmd(cmd, tid).decode("utf-8")
        await event.respond(f"""
◇━━━━━━━━━━━━━━━━◇
    ** ⟨🔸 Shadowsocks Account🔸⟩**
◇━━━━━━━━━━━━━━━━◇
```
{z}
```
""")
        async with bot.conversation(chat) as user:
            await event.respond(' **🔡Username:**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text.replace(" ", "")
            cmd_check = f'grep "^#!! {user} " /etc/xray/config.json'
            if subprocess.call(cmd_check, shell=True) != 0:
                await event.respond("**Username tidak ditemukan.**", buttons=[
                    [Button.inline("🔄 Ulangi", "delete-shadowsocks")],
                    [Button.inline("❌ Batal", "shadowsocks")]])
                return
            cmd = f'printf "%s\n" "{user}" | delss'
        try:
            a = exec_cmd(cmd, tid).decode("utf-8")
        except:
            await event.respond(f"**User** `{user}` **Successfully Deleted**",buttons=[[Button.inline("‹ Kembali","shadowsocks")]])
        else:
            inline=[[Button.inline("‹ Kembali","shadowsocks")]]
            msg = f"""**Successfully Deleted**"""
            await event.respond(msg,buttons=inline)
    await delete_shadowsocks_(event)

@bot.on(events.CallbackQuery(data=b'trial-shadowsocks'))
async def trial_shadowsocks(event):
    chat = event.chat_id
    sender = await event.get_sender()
    tid = str(sender.id)
    a = valid(str(sender.id))
    if a != "true":
        await event.answer("Akses Ditolak",alert=True)
        return
    svr_label = ""
    svr_id = get_active(tid)
    if svr_id is not None:
        s = get_server(svr_id)
        if s:
            svr_label = f"\n**📍 Remote:** `{s['name']}`"
    async def trial_shadowsocks_(event):
        nonlocal svr_label
        async with bot.conversation(chat) as exp:
            await event.respond("**Choose Expiry Minutes**",buttons=[
[Button.inline(" 10 Menit ","10"),
Button.inline(" 15 Menit ","15")],
[Button.inline(" 30 Menit ","30"),
Button.inline(" 60 Menit ","60")]])
            exp = exp.wait_event(events.CallbackQuery)
            exp = (await exp).data.decode("ascii")
        cmd = f'printf "%s\n" "{exp}" | trialss'
        try:
            a = exec_cmd(cmd, tid).decode("utf-8")
        except:
            await event.respond("**User Already Exist**")
        else:
            inline=[[Button.inline("‹ Kembali","menu")]]
            x = [x.group() for x in re.finditer("ss://(.*)",a)]
            print(x)
            remarks = re.search("#(.*)",x[0]).group(1)
            uuid = re.search("ss://(.*?)@",x[0]).group(1)
            msg = f"""
🌑 **SHADOWSOCKS ACCOUNT**

👤 **Username** : `{remarks}`
🌐 **Host** : `{DOMAIN}`
📱 **Limit IP** : `-`
📦 **Quota** : `Unlimited`
⏳ **Expired** : `{exp} Minutes`

◇━━━━━━━━━━━━━━━━◇
🔗 **TLS** : `{x[0]}`
🔗 **gRPC** : `{x[2].replace(" ","")}`
💾 **OpenClash** : [Klik Disini](https://{DOMAIN}:81/ss-{remarks}.txt)
{svr_label}
"""
            await event.respond(msg,buttons=inline)
    await trial_shadowsocks_(event)

@bot.on(events.CallbackQuery(data=b'bot-member-ss'))
async def bot_member_ss(event):
    async def bot_member_ss_(event):
        cmd = 'cat /etc/xray/config.json | grep "^#!!" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
        x = exec_cmd(cmd, tid)
        print(x)
        z = exec_cmd(cmd, tid).decode("utf-8")
        await event.respond(f"""
◇━━━━━━━━━━━━━━━━◇
    ** ⟨🔸 Shadowsocks Account🔸⟩**
◇━━━━━━━━━━━━━━━━◇
```
{z}
```
**Menampilkan Member Shadowsocks**
» 🤖 @WendiVpn
""",buttons=[[Button.inline("‹ Kembali","menu")]])
    sender = await event.get_sender()
    tid = str(sender.id)
    a = valid(str(sender.id))
    if a == "true":
        await bot_member_ss_(event)
    else:
        await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'renew-ss'))
async def renew_ss(event):
    chat = event.chat_id
    sender = await event.get_sender()
    tid = str(sender.id)
    a = valid(str(sender.id))
    if a != "true":
        await event.answer("Akses Ditolak",alert=True)
        return
    async def renew_ss_(event):
        cmd = 'cat /etc/xray/config.json | grep "^#!!" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
        x = exec_cmd(cmd, tid)
        print(x)
        z = exec_cmd(cmd, tid).decode("utf-8")
        await event.respond(f"""
◇━━━━━━━━━━━━━━━━◇
    ** ⟨🔸 Shadowsocks Account🔸⟩**
◇━━━━━━━━━━━━━━━━◇
```
{z}
```
""")
        async with bot.conversation(chat) as user:
            await event.respond(' **🔡Username Renew:**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text.replace(" ", "")
            cmd_check = f'grep "^#!! {user} " /etc/xray/config.json'
            if subprocess.call(cmd_check, shell=True) != 0:
                await event.respond("**Username tidak ditemukan.**", buttons=[
                    [Button.inline("🔄 Ulangi", "renew-ss")],
                    [Button.inline("❌ Batal", "shadowsocks")]])
                return
        async with bot.conversation(chat) as exp:
            await event.respond(' **Ubah Masaaktif:**')
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text
            if not exp.isdigit():
                await event.respond(" **Masaaktif harus berupa angka.**", buttons=[
[Button.inline("🔄 Renew Ulang","renew-ss")],
[Button.inline("❌ Batal","shadowsocks")]])
                return
            cmd = f'printf "%s\n" "{user}" "{exp}" | renewss'
        try:
            a = exec_cmd(cmd, tid).decode("utf-8")
        except:
            await event.respond(f"**User** `{user}` **Not Found**",buttons=[[Button.inline("‹ Kembali","menu")]])
        else:
            await event.respond(f"**Successfully Renew** `{user}`",buttons=[[Button.inline("‹ Kembali","menu")]])
    await renew_ss_(event)

@bot.on(events.CallbackQuery(data=b'shadowsocks'))
async def shadowsocks(event):
    async def shadowsocks_(event):
        inline = [
[Button.inline("⚡️ Auto SS","auto-shadowsocks")],
[Button.inline("☣️ Trial","trial-shadowsocks"),
Button.inline("➕ Create","create-shadowsocks")],
[Button.inline("♻️ Renew","renew-ss"),
Button.inline("👤 Member","bot-member-ss")],
[Button.inline("✅ Check","cek-shadowsocks"),
Button.inline("❌ Delete","delete-shadowsocks")],
[Button.inline("🔒 Lock","lock-ss"),
Button.inline("🔐 Unlock","unlock-ss")],
[Button.inline("📝 Detail","d-ss")],
[Button.inline("‹ Kembali","menu")]]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        ss = f' cat /etc/shadowsocks/.shadowsocks.db | grep "###" | wc -l'
        ssk = exec_cmd(ss, tid).decode("ascii")
        username = sender.username
        user_id = sender.id
        msg = f"""
🌑 **SHADOWSOCKS MANAGER**

🌐 **Host** : `{DOMAIN}`
📊 **Total** : `{ssk.strip()}` akun
🆔 **ID** : `{user_id}` 👤 **@{username}**
"""
        await event.edit(msg,buttons=inline)
    sender = await event.get_sender()
    tid = str(sender.id)
    a = valid(str(sender.id))
    if a == "true":
        await shadowsocks_(event)
    else:
        await event.answer("Access Denied",alert=True)
