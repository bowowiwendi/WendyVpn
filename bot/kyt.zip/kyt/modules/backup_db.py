from kyt import *
import asyncio

def _init_config():
    db = get_db()
    db.execute("CREATE TABLE IF NOT EXISTS bot_config (key TEXT PRIMARY KEY, value TEXT)")
    db.execute("INSERT OR IGNORE INTO bot_config (key, value) VALUES ('auto_db_backup', 'disabled')")
    db.execute("INSERT OR IGNORE INTO bot_config (key, value) VALUES ('auto_db_backup_last', '')")
    db.commit()

_init_config()

async def send_db_to_admins():
    db_path = "kyt/database.db"
    if not os.path.exists(db_path):
        return
    admins = get_db().execute("SELECT user_id FROM admin").fetchall()
    now_str = DT.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    for admin in admins:
        try:
            await bot.send_file(int(admin['user_id']), db_path,
                caption=f"📦 **Auto Backup Database**\n\n🕐 `{now_str}`\n\n_Bot database otomatis dikirim 2x sehari._")
        except:
            pass

async def db_backup_scheduler():
    while True:
        await asyncio.sleep(3600)
        try:
            db = get_db()
            config = db.execute("SELECT value FROM bot_config WHERE key='auto_db_backup'").fetchone()
            if not config or config['value'] != 'enabled':
                continue
            last_row = db.execute("SELECT value FROM bot_config WHERE key='auto_db_backup_last'").fetchone()
            last_time = last_row['value'] if last_row else ''
            now = DT.datetime.now()
            if last_time:
                try:
                    last_dt = DT.datetime.strptime(last_time, '%Y-%m-%d %H:%M:%S')
                    diff = (now - last_dt).total_seconds()
                    if diff < 43200:
                        continue
                except:
                    pass
            await send_db_to_admins()
            db.execute("UPDATE bot_config SET value=? WHERE key='auto_db_backup_last'",
                (now.strftime('%Y-%m-%d %H:%M:%S'),))
            db.commit()
        except:
            pass

@bot.on(events.CallbackQuery(data=b'auto_db_backup'))
async def auto_db_backup(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return
    db = get_db()
    config = db.execute("SELECT value FROM bot_config WHERE key='auto_db_backup'").fetchone()
    status = config['value'] if config else 'disabled'
    label = "🟢 ON" if status == "enabled" else "🔴 OFF"
    msg = f"""⚙️ **Auto DB Backup**

**Status : {label}**

Bot database (`database.db`) akan dikirim otomatis ke admin 2x sehari (setiap 12 jam).

Gunakan tombol di bawah untuk mengaktifkan atau menonaktifkan."""
    await event.edit(msg, buttons=[
        [Button.inline(f"{'🔴 Nonaktifkan' if label == '🟢 ON' else '🟢 Aktifkan'}", "toggle_db_backup")],
        [Button.inline("‹ Kembali", "setting")]
    ])

@bot.on(events.CallbackQuery(data=b'toggle_db_backup'))
async def toggle_db_backup(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return
    db = get_db()
    config = db.execute("SELECT value FROM bot_config WHERE key='auto_db_backup'").fetchone()
    status = config['value'] if config else 'disabled'
    new_status = 'disabled' if status == 'enabled' else 'enabled'
    db.execute("UPDATE bot_config SET value=? WHERE key='auto_db_backup'", (new_status,))
    if new_status == 'enabled':
        now = DT.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        db.execute("UPDATE bot_config SET value=? WHERE key='auto_db_backup_last'", (now,))
    db.commit()
    label = "🟢 ON" if new_status == "enabled" else "🔴 OFF"
    msg = f"""⚙️ **Auto DB Backup**

**Status : {label}**

Bot database (`database.db`) akan dikirim otomatis ke admin 2x sehari (setiap 12 jam).

Gunakan tombol di bawah untuk mengaktifkan atau menonaktifkan."""
    await event.edit(msg, buttons=[
        [Button.inline(f"{'🔴 Nonaktifkan' if label == '🟢 ON' else '🟢 Aktifkan'}", "toggle_db_backup")],
        [Button.inline("‹ Kembali", "setting")]
    ])
