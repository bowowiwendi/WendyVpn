from kyt import *
import asyncio

def _init_config():
    db = get_db()
    db.execute("CREATE TABLE IF NOT EXISTS bot_config (key TEXT PRIMARY KEY, value TEXT)")
    db.execute("INSERT OR IGNORE INTO bot_config (key, value) VALUES ('auto_db_backup', 'disabled')")
    db.execute("INSERT OR IGNORE INTO bot_config (key, value) VALUES ('auto_db_backup_last', '')")
    db.commit()

_init_config()

async def send_db_to_admins(label="Auto Backup"):
    db_path = "kyt/database.db"
    if not os.path.exists(db_path):
        return
    admins = get_db().execute("SELECT user_id FROM admin").fetchall()
    now_str = DT.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    for admin in admins:
        try:
            await bot.send_file(int(admin['user_id']), db_path,
                caption=f"📦 **{label}**\n\n🕐 `{now_str}`")
        except:
            pass

async def db_backup_scheduler():
    while True:
        await asyncio.sleep(3600)
        try:
            db = get_db()
            config = db.execute("SELECT value FROM bot_config WHERE key='auto_db_backup'").fetchone()
            if not config or config['value'] != 'enabled':
                continue
            last_row = db.execute("SELECT value FROM bot_config WHERE key='auto_db_backup_last'").fetchone()
            last_time = last_row['value'] if last_row else ''
            now = DT.datetime.now()
            if not last_time:
                continue
            try:
                last_dt = DT.datetime.strptime(last_time, '%Y-%m-%d %H:%M:%S')
            except:
                continue
            diff = (now - last_dt).total_seconds()
            if diff < 43200:
                continue
            await send_db_to_admins("Auto Backup Database")
            db.execute("UPDATE bot_config SET value=? WHERE key='auto_db_backup_last'",
                (now.strftime('%Y-%m-%d %H:%M:%S'),))
            db.commit()
        except:
            pass

@bot.on(events.CallbackQuery(data=b'auto_db_backup'))
async def auto_db_backup(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return
    db = get_db()
    config = db.execute("SELECT value FROM bot_config WHERE key='auto_db_backup'").fetchone()
    status = config['value'] if config else 'disabled'
    label = "🟢 ON" if status == "enabled" else "🔴 OFF"
    msg = f"""**◇━━━━━━━━━━◇**
**📦 DATABASE BACKUP**
**◇━━━━━━━━━━◇**

**Auto Backup : {label}**

Bot database otomatis dikirim ke admin 2x sehari.

**Manual:** Gunakan tombol **Backup Now** untuk kirim database sekarang."""
    await event.edit(msg, buttons=[
        [Button.inline("📤 Backup Now", "backup_db_now")],
        [Button.inline(f"{'🔴 Nonaktifkan' if label == '🟢 ON' else '🟢 Aktifkan'}", "toggle_db_backup")],
        [Button.inline("📥 Restore DB", "restore_db")],
        [Button.inline("‹ Kembali", "setting")]
    ])

@bot.on(events.CallbackQuery(data=b'backup_db_now'))
async def backup_db_now(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return
    await event.respond("⏳ **Mengirim database...**")
    await send_db_to_admins("Manual Backup Database")
    await event.respond("✅ **Database terkirim!**",
        buttons=[[Button.inline("‹ Kembali", "auto_db_backup")]])

@bot.on(events.CallbackQuery(data=b'toggle_db_backup'))
async def toggle_db_backup(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return
    db = get_db()
    config = db.execute("SELECT value FROM bot_config WHERE key='auto_db_backup'").fetchone()
    status = config['value'] if config else 'disabled'
    new_status = 'disabled' if status == 'enabled' else 'enabled'
    db.execute("UPDATE bot_config SET value=? WHERE key='auto_db_backup'", (new_status,))
    if new_status == 'enabled':
        now = DT.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        db.execute("UPDATE bot_config SET value=? WHERE key='auto_db_backup_last'", (now,))
    db.commit()
    label = "🟢 ON" if new_status == "enabled" else "🔴 OFF"
    msg = f"""**◇━━━━━━━━━━◇**
**📦 DATABASE BACKUP**
**◇━━━━━━━━━━◇**

**Auto Backup : {label}**

Bot database otomatis dikirim ke admin 2x sehari.

**Manual:** Gunakan tombol **Backup Now** untuk kirim database sekarang."""
    await event.edit(msg, buttons=[
        [Button.inline("📤 Backup Now", "backup_db_now")],
        [Button.inline(f"{'🔴 Nonaktifkan' if label == '🟢 ON' else '🟢 Aktifkan'}", "toggle_db_backup")],
        [Button.inline("📥 Restore DB", "restore_db")],
        [Button.inline("‹ Kembali", "setting")]
    ])

@bot.on(events.CallbackQuery(data=b'restore_db'))
async def restore_db(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return
    chat = event.chat_id
    guide = """**📥 RESTORE DATABASE**

**Panduan:**

1. Cari pesan **Backup Database** di chat ini
2. Tap file `database.db` di pesan itu, lalu kirim ulang
3. Atau upload file `.db` langsung dari penyimpanan

**Peringatan:** Database saat ini akan diganti!
Database lama akan di-backup sebagai `database.db.bak`

Kirim file **database.db** sekarang:"""
    await event.respond(guide,
        buttons=[[Button.inline("❌ Batal", "auto_db_backup")]])
    try:
        async with bot.conversation(chat, timeout=120) as conv:
            r = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            msg = r.message
    except:
        await event.respond("⏱️ **Timeout!** Silakan coba lagi.",
            buttons=[[Button.inline("‹ Kembali", "auto_db_backup")]])
        return
    if not msg.file or not msg.file.name:
        await event.respond("❌ **Bukan file!** Kirim file `database.db`.",
            buttons=[[Button.inline("‹ Kembali", "auto_db_backup")]])
        return
    await event.respond("⏳ **Mengunduh file...**")
    dl_path = f"/tmp/kyt_restore_{random.randint(10000,99999)}.db"
    try:
        await msg.download_media(dl_path)
    except:
        await event.respond("❌ **Gagal mengunduh file.**",
            buttons=[[Button.inline("‹ Kembali", "auto_db_backup")]])
        return
    try:
        test_db = sqlite3.connect(dl_path)
        test_db.execute("SELECT 1 FROM user_balance LIMIT 1")
        test_db.close()
    except:
        os.unlink(dl_path)
        await event.respond("❌ **File tidak valid!** Bukan database bot yang benar.",
            buttons=[[Button.inline("‹ Kembali", "auto_db_backup")]])
        return
    db_path = "kyt/database.db"
    if os.path.exists(db_path):
        bak_path = "kyt/database.db.bak"
        try:
            if os.path.exists(bak_path):
                os.unlink(bak_path)
            os.rename(db_path, bak_path)
        except:
            pass
    os.rename(dl_path, db_path)
    await event.respond(
        "✅ **Restore berhasil!**\n\n"
        "♻️ **Restart bot** agar perubahan diterapkan.\n\n"
        "Cara restart:\n"
        "• Ketik `/menu` → Setting → Restart\n"
        "• Atau: `systemctl restart kyt` via SSH",
        buttons=[[Button.inline("‹ Kembali", "auto_db_backup")]]
    )
