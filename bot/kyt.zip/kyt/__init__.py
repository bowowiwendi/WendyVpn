from telethon import *
import datetime as DT
from telethon import *
import requests,time,os,subprocess,re,sqlite3,sys,random,base64,json,math,shlex,asyncio
import logging
#usr/local/bin/kyt
logging.basicConfig(level=logging.INFO)
uptime = DT.datetime.now()

exec(open("kyt/var.txt","r").read())
bot = TelegramClient("ddsdswl","6","eb06d4abfb49dc3eeb1aeb98ae0f581e").start(bot_token=BOT_TOKEN)

API_BASE = os.environ.get("WENDY_API_BASE", "http://127.0.0.1:9000")
API_TOKEN_FILE = os.environ.get("WENDY_API_TOKEN_FILE", "/etc/wendy-api/token")


def api_token():
    try:
        with open(API_TOKEN_FILE, "r", encoding="utf-8") as handle:
            return handle.read().strip()
    except Exception:
        return ""


def api_account_command(cmd, timeout=120):
    """Run legacy account command through the Wendy API account endpoints."""
    mapped = api_map_account_command(cmd)
    if not mapped:
        raise ValueError("account command is not supported by API mapping")
    endpoint, payload = mapped
    return api_post(endpoint, payload, timeout=timeout)


def api_maintenance_command(cmd, timeout=180):
    """Run supported maintenance command through dedicated API endpoints."""
    mapped = api_map_maintenance_command(cmd)
    if not mapped:
        raise ValueError("maintenance command is not supported by API mapping")
    endpoint, payload = mapped
    return api_post(endpoint, payload, timeout=timeout)


def api_create_account(service, username, password="", limit_ip="2", quota="100", days="1", bug="", trial=False, timeout=120):
    payload = {
        "service": service,
        "username": username,
        "password": password,
        "limit_ip": str(limit_ip),
        "quota": str(quota),
        "days": str(days),
        "bug": bug,
        "trial": bool(trial),
    }
    return api_post("/api/accounts/create", payload, timeout=timeout)


def api_renew_account(service, username, days="1", quota="100", limit_ip="2", timeout=120):
    payload = {
        "service": service,
        "username": username,
        "days": str(days),
        "quota": str(quota),
        "limit_ip": str(limit_ip),
    }
    return api_post("/api/accounts/renew", payload, timeout=timeout)


def api_delete_account(service, username, timeout=120):
    return api_post("/api/accounts/delete", {"service": service, "username": username}, timeout=timeout)


def api_post(endpoint, payload, timeout=None):
    headers = {}
    token = api_token()
    if token:
        headers["X-API-Token"] = token
    response = requests.post(
        f"{API_BASE}{endpoint}",
        json=payload,
        headers=headers,
        timeout=timeout or 120,
    )
    payload = response.json()
    if response.status_code != 200 or not payload.get("ok"):
        message = payload.get("stderr") or payload.get("error") or "api command failed"
        raise subprocess.CalledProcessError(payload.get("returncode", response.status_code), endpoint, output=payload.get("stdout", ""), stderr=message)
    return payload.get("stdout", "") or payload.get("account_text", "")


def api_extract_printf(cmd):
    if not isinstance(cmd, str):
        return None
    match = re.match(r"^printf\s+['\"]%s\\n['\"]\s+(.*?)\s+\|\s*([A-Za-z0-9_.-]+)\s*$", cmd.strip(), re.S)
    if not match:
        return None
    try:
        values = shlex.split(match.group(1))
    except Exception:
        return None
    return values, match.group(2)


def api_map_account_command(cmd):
    parsed = api_extract_printf(cmd)
    if not parsed:
        return None
    values, script = parsed
    create_map = {
        'addssh': 'ssh', 'addws': 'vmess', 'addvless': 'vless',
        'addtr': 'trojan', 'addss': 'shadowsocks',
    }
    trial_map = {
        'trial': 'ssh', 'trialws': 'vmess', 'trialvless': 'vless',
        'trialtr': 'trojan', 'trialss': 'shadowsocks',
    }
    renew_map = {
        'renewssh': 'ssh', 'renewws': 'vmess', 'renewvless': 'vless',
        'renewtr': 'trojan', 'renewss': 'shadowsocks',
    }
    delete_map = {
        'delssh': 'ssh', 'delws': 'vmess', 'delvless': 'vless',
        'deltr': 'trojan', 'delss': 'shadowsocks',
    }
    if script in create_map:
        svc = create_map[script]
        if svc == 'ssh' and len(values) >= 4:
            return "/api/accounts/create", {"service": svc, "username": values[0], "password": values[1], "limit_ip": values[2], "days": values[3], "bug": values[4] if len(values) > 4 else ""}
        if svc in ('vmess', 'vless', 'trojan') and len(values) >= 4:
            return "/api/accounts/create", {"service": svc, "username": values[0], "limit_ip": values[1], "quota": values[2], "days": values[3], "bug": values[4] if len(values) > 4 else ""}
        if svc == 'shadowsocks' and len(values) >= 4:
            return "/api/accounts/create", {"service": svc, "username": values[0], "limit_ip": values[1], "days": values[2], "quota": values[3], "bug": values[4] if len(values) > 4 else ""}
    if script in trial_map:
        svc = trial_map[script]
        if svc == 'ssh' and len(values) >= 4:
            return "/api/accounts/create", {"service": svc, "username": values[0], "password": values[1], "limit_ip": values[2], "days": values[3], "trial": True}
        if len(values) >= 1:
            return "/api/accounts/create", {"service": svc, "days": values[0], "trial": True, "username": "trial"}
    if script in renew_map and len(values) >= 2:
        svc = renew_map[script]
        payload = {"service": svc, "username": values[0], "days": values[1]}
        if svc in ('vmess', 'vless', 'trojan'):
            payload["quota"] = values[2] if len(values) > 2 else "100"
            payload["limit_ip"] = values[3] if len(values) > 3 else "2"
        return "/api/accounts/renew", payload
    if script in delete_map and len(values) >= 1:
        return "/api/accounts/delete", {"service": delete_map[script], "username": values[0]}
    return None


def api_map_maintenance_command(cmd):
    if not isinstance(cmd, str):
        return None
    normalized = cmd.strip()
    if normalized == 'xp':
        return '/api/maintenance/xp', {}
    if normalized == 'clean_lock.sh':
        return '/api/maintenance/clean-lock', {}
    if normalized == 'bot-backup':
        return '/api/maintenance/backup', {}
    if normalized == 'notif_delet':
        return '/api/maintenance/notif-delet', {}
    if normalized == 'notif_backup':
        return '/api/maintenance/notif-backup', {}
    if normalized == 'notif_limit':
        return '/api/maintenance/notif-limit', {}
    if normalized == 'reboot':
        return '/api/maintenance/reboot', {}
    if normalized == 'speedtest-cli --share':
        return '/api/maintenance/speedtest', {}
    if normalized == 'fixcert':
        return '/api/maintenance/fixcert', {}
    if normalized == "printf '%s\n' '3' | auto-delet.sh":
        return '/api/maintenance/toggle-auto-delete', {'state': 'on'}
    if normalized == "printf '%s\n' '1' | auto-delet.sh":
        return '/api/maintenance/toggle-auto-delete', {'state': 'off'}
    if normalized == "printf '%s\n' '8' | auto-backup.sh":
        return '/api/maintenance/toggle-auto-backup', {'state': 'on'}
    if normalized == "printf '%s\n' '3' | auto-backup.sh":
        return '/api/maintenance/toggle-auto-backup', {'state': 'off'}
    if normalized == "printf '%s\n' '1' | onoff":
        return '/api/maintenance/toggle-limit', {'state': 'on'}
    if normalized == "printf '%s\n' '2' | onoff":
        return '/api/maintenance/toggle-limit', {'state': 'off'}
    if normalized.startswith("printf '%s\\n' ") and normalized.endswith("| addhost"):
        match = re.match(r"^printf '%s\\n' \"?(.*?)\"? \| addhost$", normalized)
        if match:
            return '/api/maintenance/addhost', {'domain': match.group(1)}
    if normalized.startswith("printf '%s\\n' ") and normalized.endswith("| bot-restore"):
        match = re.match(r"^printf '%s\\n' \"?(.*?)\"? \| bot-restore$", normalized)
        if match:
            return '/api/maintenance/restore', {'link': match.group(1)}
    restart_match = re.match(r'^(?:systemctl\s+restart\s+|service\s+restart\s+)?([A-Za-z0-9@._-]+)$', normalized)
    if restart_match and normalized.startswith('systemctl restart '):
        return '/api/maintenance/restart', {'service': restart_match.group(1)}
    enable_match = re.match(r'^systemctl\s+enable\s+--now\s+([A-Za-z0-9@._-]+)$', normalized)
    if enable_match:
        return '/api/maintenance/enable', {'service': enable_match.group(1)}
    return None

try:
    open("kyt/database.db")
except:
    x = sqlite3.connect("kyt/database.db")
    c = x.cursor()
    c.execute("CREATE TABLE admin (user_id)")
    c.execute("INSERT INTO admin (user_id) VALUES (?)",(ADMIN,))
    x.commit()

def get_db():
    x = sqlite3.connect("kyt/database.db")
    x.row_factory = sqlite3.Row
    return x

def valid(id):
    db = get_db()
    x = db.execute("SELECT user_id FROM admin").fetchall()
    a = [v[0] for v in x]
    if id in a:
        return "true"
    else:
        return "false"

def validate_username(username):
    """Validasi username: hanya huruf, angka, underscore, hyphen (max 32 karakter)"""
    return bool(re.match(r'^[a-zA-Z0-9_-]{1,32}$', username))

def convert_size(size_bytes):
   if size_bytes == 0:
       return "0B"
   size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
   i = int(math.floor(math.log(size_bytes, 1024)))
   p = math.pow(1024, i)
   s = round(size_bytes / p, 2)
   return "%s %s" % (s, size_name[i])

def generate_qr(data, label="qr"):
    if not data:
        return None
    path = f"/tmp/kyt_qr_{label}_{random.randint(10000,99999)}.png"
    try:
        import qrcode
        img = qrcode.make(data, image_factory=qrcode.image.pil.PilImage)
        img.save(path, format="PNG")
        if os.path.getsize(path) > 0:
            return path
    except Exception as e:
        try:
            os.unlink(path)
        except:
            pass
    try:
        import urllib.parse
        encoded = urllib.parse.quote(data, safe="")
        r = requests.get(f"https://api.qrserver.com/v1/create-qr-code/?size=500x500&data={encoded}", timeout=30)
        if r.status_code == 200 and r.content:
            with open(path, 'wb') as f:
                f.write(r.content)
            return path
    except Exception as e:
        pass
    return None


def download_qr_image(url, label="qris"):
    path = f"/tmp/kyt_qr_{label}_{random.randint(10000,99999)}.png"
    try:
        r = requests.get(url, timeout=30)
        if r.status_code == 200 and r.content:
            with open(path, 'wb') as f:
                f.write(r.content)
            return path
    except:
        pass
    return None

# ── USER PANEL DATABASE ───────────────────────────────────────────────
def _init_user_tables():
    _db = sqlite3.connect("kyt/database.db")
    _db.execute("""CREATE TABLE IF NOT EXISTS user_balance (
        telegram_id TEXT PRIMARY KEY,
        balance REAL DEFAULT 0,
        tg_username TEXT DEFAULT '',
        joined_at TEXT DEFAULT (datetime('now','localtime'))
    )""")
    _db.execute("""CREATE TABLE IF NOT EXISTS user_services (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        telegram_id TEXT NOT NULL,
        service TEXT NOT NULL,
        username TEXT NOT NULL,
        expired_at TEXT,
        created_at TEXT DEFAULT (datetime('now','localtime'))
    )""")
    _db.execute("""CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        telegram_id TEXT NOT NULL,
        type TEXT NOT NULL,
        amount REAL NOT NULL,
        description TEXT DEFAULT '',
        created_at TEXT DEFAULT (datetime('now','localtime'))
    )""")
    _db.execute("""CREATE TABLE IF NOT EXISTS service_prices (
        service TEXT NOT NULL,
        duration INTEGER NOT NULL,
        price REAL NOT NULL,
        PRIMARY KEY (service, duration)
    )""")
    for svc in ['ssh','vmess','vless','trojan','shadowsocks']:
        for dur, price in [(1,1000),(7,3000),(15,5000),(30,10000)]:
            _db.execute("INSERT OR IGNORE INTO service_prices VALUES (?,?,?)", (svc, dur, price))
    _db.commit()
    _db.close()

_init_user_tables()

def format_rupiah(amount):
    return f"Rp {int(amount):,}".replace(',','.')

def ensure_user_exists(telegram_id, tg_username=''):
    db = get_db()
    db.execute("INSERT OR IGNORE INTO user_balance (telegram_id, tg_username) VALUES (?,?)",
        (str(telegram_id), tg_username))
    if tg_username:
        db.execute("UPDATE user_balance SET tg_username=? WHERE telegram_id=?",
            (tg_username, str(telegram_id)))
    db.commit()

def get_balance(telegram_id):
    db = get_db()
    row = db.execute("SELECT balance FROM user_balance WHERE telegram_id=?", (str(telegram_id),)).fetchone()
    return float(row['balance']) if row else 0.0

def add_balance(telegram_id, amount, description="Top Up"):
    db = get_db()
    ensure_user_exists(telegram_id)
    db.execute("UPDATE user_balance SET balance=balance+? WHERE telegram_id=?", (amount, str(telegram_id)))
    db.execute("INSERT INTO transactions (telegram_id,type,amount,description) VALUES (?,'topup',?,?)",
        (str(telegram_id), amount, description))
    db.commit()

def deduct_balance(telegram_id, amount, description="Pembelian"):
    db = get_db()
    bal = get_balance(telegram_id)
    if bal < amount:
        return False
    db.execute("UPDATE user_balance SET balance=balance-? WHERE telegram_id=?", (amount, str(telegram_id)))
    db.execute("INSERT INTO transactions (telegram_id,type,amount,description) VALUES (?,'purchase',?,?)",
        (str(telegram_id), amount, description))
    db.commit()
    return True

def get_user_services(telegram_id):
    db = get_db()
    return db.execute("SELECT * FROM user_services WHERE telegram_id=? ORDER BY created_at DESC",
        (str(telegram_id),)).fetchall()

def get_service_prices(service):
    db = get_db()
    return db.execute("SELECT duration, price FROM service_prices WHERE service=? ORDER BY duration",
        (service,)).fetchall()

# ── TRIAL SYSTEM ─────────────────────────────────────────────────────
def _init_trial_table():
    _db = sqlite3.connect("kyt/database.db")
    _db.execute("""CREATE TABLE IF NOT EXISTS trial_claims (
        telegram_id TEXT NOT NULL,
        claim_date TEXT NOT NULL,
        service TEXT NOT NULL,
        username TEXT NOT NULL,
        created_at TEXT DEFAULT (datetime('now','localtime')),
        PRIMARY KEY (telegram_id, claim_date)
    )""")
    _db.commit()
    _db.close()

_init_trial_table()

def can_claim_trial(telegram_id):
    today = DT.date.today().isoformat()
    db = get_db()
    row = db.execute("SELECT 1 FROM trial_claims WHERE telegram_id=? AND claim_date=?",
        (str(telegram_id), today)).fetchone()
    return row is None

def record_trial_claim(telegram_id, service, username):
    today = DT.date.today().isoformat()
    db = get_db()
    db.execute("INSERT INTO trial_claims (telegram_id, claim_date, service, username) VALUES (?,?,?,?)",
        (str(telegram_id), today, service, username))
    db.commit()

def build_trial_cmd(svc, username, password, limit_ip):
    u = shlex.quote(username)
    p = shlex.quote(password)
    l = shlex.quote(limit_ip)
    cmds = {
        'ssh':         f'printf "%s\\n" {u} {p} {l} 1 "" | addssh',
        'vmess':       f'printf "%s\\n" {u} {l} 100 1 "" | addws',
        'vless':       f'printf "%s\\n" {u} {l} 100 1 "" | addvless',
        'trojan':      f'printf "%s\\n" {u} {l} 100 1 "" | addtr',
        'shadowsocks': f'printf "%s\\n" {u} {l} 1 100 "" | addss',
    }
    return cmds.get(svc, '')

TRIAL_SCRIPT = {
    'ssh': 'ssh', 'vmess': 'vmess', 'vless': 'vless',
    'trojan': 'trojan', 'shadowsocks': 'shadowsocks',
}
